# Databricks notebook source
# MAGIC %md
# MAGIC ## Save Top 10 drivers of every race year into a new table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_presentation.calculated_top10_driver_every_year
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT race_year, driver_name, position, points, calculated_points
# MAGIC FROM f1_presentation.race_results_sql
# MAGIC WHERE position <= 10

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from f1_presentation.calculated_top10_driver_every_year
# MAGIC order by race_year DESC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Find Dominant drivers of all time

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_presentation.calculated_dominant_drivers_all_time
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT driver_name, 
# MAGIC       count(1) AS total_races, 
# MAGIC       sum(calculated_points) AS total_calculated_points,
# MAGIC       avg(calculated_points) AS avg_calculated_points
# MAGIC FROM f1_presentation.race_results_sql
# MAGIC GROUP BY driver_name
# MAGIC HAVING total_races >=50
# MAGIC ORDER BY avg_calculated_points DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC From f1_presentation.calculated_dominant_drivers_all_time

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Find Dominant drivers in the period from 2013-2023
# MAGIC SELECT driver_name,
# MAGIC       count(1) AS total_races, 
# MAGIC       sum(calculated_points) AS total_calculated_points,
# MAGIC       avg(calculated_points) AS avg_calculated_points
# MAGIC FROM f1_presentation.race_results_sql
# MAGIC WHERE race_year BETWEEN 2013 AND 2023
# MAGIC GROUP BY driver_name
# MAGIC HAVING total_races >=50
# MAGIC ORDER BY avg_calculated_points DESC