# Databricks notebook source
df_dominant_drivers_all_time_sql=spark.read.format('delta').load('/mnt/dlrosies/f1presentation/calculated_dominant_drivers_all_time')
display(df_dominant_drivers_all_time_sql)

# COMMAND ----------

from pyspark.sql import *
import pandas as pd

# COMMAND ----------

    jdbcHostname = "....database.windows.net"
    jdbcDatabase='db-....'
    jdbcPort="1433"
    properties= {"user":"user","password":"password"}
    url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
    df3=DataFrameWriter(df_dominant_drivers_all_time_sql)
    df3.jdbc(url,table="[f1_reporting].[dominant_drivers_sql]",mode="Overwrite",properties=properties)