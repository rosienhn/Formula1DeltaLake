# Databricks notebook source
# MAGIC %md
# MAGIC ### Find Dominant teams of all time

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_presentation.calculated_dominant_teams_all_time
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT team_name, 
# MAGIC       count(1) AS total_races, 
# MAGIC       sum(calculated_points) AS total_calculated_points,
# MAGIC       avg(calculated_points) AS avg_calculated_points
# MAGIC FROM f1_presentation.race_results_sql
# MAGIC GROUP BY team_name
# MAGIC HAVING total_races >=100
# MAGIC ORDER BY avg_calculated_points DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Find Dominant teams in the period from 2013-2023
# MAGIC SELECT team_name,
# MAGIC       count(1) AS total_races, 
# MAGIC       sum(calculated_points) AS total_calculated_points,
# MAGIC       avg(calculated_points) AS avg_calculated_points
# MAGIC FROM f1_presentation.race_results_sql
# MAGIC WHERE race_year BETWEEN 2013 AND 2023
# MAGIC GROUP BY team_name
# MAGIC HAVING total_races >=50
# MAGIC ORDER BY avg_calculated_points DESC