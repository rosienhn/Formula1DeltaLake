# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join races and circuits 

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

races_df = spark.read.format('delta').load(f'{processed_folder_path}/races') \
.withColumnRenamed('race_timestamp','race_date') 

# COMMAND ----------

circuits_df = spark.read.format('delta').load(f'{processed_folder_path}/circuits') \
.withColumnRenamed('name','circuit_name') \
.withColumnRenamed('location','circuit_location') 

# COMMAND ----------

races_circuits_df =races_df.join(circuits_df,races_df.circuit_id == circuits_df.circuit_id,'inner') \
                           .select(races_df.race_id,races_df.race_year,races_df.race_name,races_df.race_date, circuits_df.circuit_location)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join results with other dataframes

# COMMAND ----------

results_df = spark.read.format('delta').load(f'{processed_folder_path}/results') \
.filter(f"file_date = '{v_file_date}'") \
.withColumnRenamed('time','race_time') \
.withColumnRenamed('race_id','results_race_id') \
.withColumnRenamed('driver_id','results_driver_id') \
.withColumnRenamed('file_date','results_file_date')

# COMMAND ----------

constructors_df = spark.read.format('delta').load(f'{processed_folder_path}/constructors')

# COMMAND ----------

drivers_df = spark.read.format('delta').load(f'{processed_folder_path}/drivers') \
.withColumnRenamed('number','driver_number') \
.withColumnRenamed('nationality','driver_nationality')

# COMMAND ----------

race_results_df = results_df.join(drivers_df, results_df.results_driver_id == drivers_df.driver_id, 'inner') \
                            .join(constructors_df, results_df.constructor_id == constructors_df.constructor_id, 'inner') \
                            .join(races_circuits_df, results_df.results_race_id == races_circuits_df.race_id, 'inner')

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

display(race_results_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df = race_results_df.select('race_id','race_year','race_name','race_date','circuit_location','driver_name','results_driver_id', \
                                  'driver_number','driver_nationality','constructor_name','grid','fastest_lap','race_time','points','position','results_file_date') \
                                  .withColumnRenamed('results_file_date','file_date') \
                                  .withColumnRenamed('results_driver_id','driver_id') \
                                  .withColumn('created_date',current_timestamp())

# COMMAND ----------

display(final_df.filter("race_year == 2020 and race_name == 'Abu Dhabi Grand Prix'").orderBy(final_df.points.desc()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Write to presentation container

# COMMAND ----------


spark.conf.set('spark.databricks.optimizer.dynamicPartitionPruning', 'true')

from delta.tables import DeltaTable
if spark.catalog.tableExists('f1_presentation.race_results'):
    deltaTable = DeltaTable.forPath(spark,'/mnt/dlrosies/f1presentation/race_results')
    deltaTable.alias('r').merge(final_df.alias('f'),'r.race_id = f.race_id AND r.driver_id = f.driver_id') \
                                         .whenMatchedUpdateAll() \
                                         .whenNotMatchedInsertAll() \
                                         .execute()
else:
    final_df.write.mode('overwrite').partitionBy('race_id').format('delta').saveAsTable('f1_presentation.race_results')

# COMMAND ----------


# def merge_delta_data(input_df,db_name,table_name,folder_path, merge_condition, partition_column):
#     spark.conf.set('spark.databricks.optimizer.dynamicPartitionPruning', 'true')

#     from delta.tables import DeltaTable
#     if (spark.catalog.tableExists(f'{db_name}.{table_name}')):
#         deltaTable = DeltaTable.forPath(spark, f'{folder_path}/{table_name}')
#         deltaTable.alias('r').merge(input_df.alias('f'), merge_condition) \
#                             .whenMatchedUpdateAll() \
#                             .whenNotMatchedInsertAll() \
#                             .execute()
#     else:
#         input_df.write.mode('overwrite').partitionBy(partition_column).format('delta').saveAsTable(f'{db_name}.{table_name}')



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_presentation.race_results

# COMMAND ----------

display(spark.read.format('delta').load(f'{presentation_folder_path}/race_results'))

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/dlrosies/f1presentation/race_results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, count(1)
# MAGIC FROM f1_presentation.race_results
# MAGIC GROUP BY race_id
# MAGIC ORDER BY race_id DESC