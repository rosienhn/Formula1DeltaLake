# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC #### Ingest races.csv file

# COMMAND ----------

dbutils.widgets.text('p_data_source', '')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1 - Read the csv file using spark dataframe reader

# COMMAND ----------

races_df = spark.read.csv(f'{raw_folder_path}/{v_file_date}/races.csv')

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

races_schema = StructType(fields=[StructField('raceId', IntegerType(), False),
                                     StructField('year', IntegerType(), True),
                                     StructField('round',IntegerType(), True),
                                     StructField('circuitId', IntegerType(), True),
                                     StructField('name', StringType(), True),
                                     StructField('date', DateType(), True),
                                     StructField('time', StringType(), True),
                                     StructField('url', StringType(), True),
                                     StructField('fp1_date', DateType(), True),
                                     StructField('fp1_time', StringType(), True),
                                     StructField('fp2_date', DateType(), True),
                                     StructField('fp2_time', StringType(), True),
                                     StructField('fp3_date', DateType(), True),
                                     StructField('fp3_time', StringType(), True),
                                     StructField('quali_date', DateType(), True),
                                     StructField('quali_time', StringType(), True),
                                     StructField('sprint_date', DateType(), True),
                                     StructField('sprint_time', StringType(), True),
                                     
])

# COMMAND ----------

races_df = spark.read. \
option("header", True). \
schema(races_schema).csv(f'{raw_folder_path}/{v_file_date}/races.csv')

# COMMAND ----------

races_df.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2- Select columns and rename columns

# COMMAND ----------

races_selected_df = races_df.select('raceId','year','round','circuitId','name','date','time') \
.withColumnRenamed('raceId','race_id') \
.withColumnRenamed('name','race_name') \
.withColumnRenamed('year','race_year') \
.withColumnRenamed('circuitId','circuit_id') 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4 - Add new columns: ingestion_date,race_timestamp  and file_date

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,to_timestamp, concat, col, lit

# COMMAND ----------

races_with_timestamp_df = races_selected_df \
.withColumn('race_timestamp', to_timestamp(concat(col('date'), lit(' '), col('time')), 'yyyy-MM-dd HH:mm:ss')) \
.withColumn('data_source',lit(v_data_source)) \
.withColumn('file_date',lit(v_file_date))

# COMMAND ----------

races_added_df = add_ingestion_date(races_with_timestamp_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Select required column

# COMMAND ----------

races_final_df = races_added_df. select('race_id','race_year','round','circuit_id','race_name','ingestion_date','race_timestamp','data_source','file_date')

# COMMAND ----------

display(races_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5 - Write data to datalake as Delta file

# COMMAND ----------

races_final_df.write.mode('overwrite').partitionBy('race_year').format('delta').saveAsTable('f1_processed.races')

# COMMAND ----------

display(spark.read.format('delta').load('/mnt/dlrosies/f1processed/races'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC from f1_processed.races

# COMMAND ----------

dbutils.notebook.exit('Success')