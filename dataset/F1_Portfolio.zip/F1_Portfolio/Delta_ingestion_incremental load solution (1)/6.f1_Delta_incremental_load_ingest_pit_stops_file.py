# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

dbutils.widgets.text('p_data_source','')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Read the pitstop.csv file using spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, IntegerType, StringType

# COMMAND ----------

pitstops_schema = StructType(fields=[StructField('raceId', IntegerType(), False),
                                      StructField('driverId', IntegerType(), True),
                                      StructField('stop', StringType(), True),
                                      StructField('lap', IntegerType(), True),
                                      StructField('time', StringType(), True),
                                      StructField('duration',StringType(), True),
                                      StructField('milliseconds', IntegerType(), True)
])

# COMMAND ----------

pitstops_df = spark.read.option('header', True). \
                        schema(pitstops_schema). \
                        csv(f'{raw_folder_path}/{v_file_date}/pit_stops.csv')

# COMMAND ----------

display(pitstops_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import lit

# COMMAND ----------

pitstops_added_df = pitstops_df.withColumnRenamed('raceId','race_id') \
                                      .withColumnRenamed('driverId','driver_id') \
                                      .withColumn('data_source',lit(v_data_source)) \
                                      .withColumn('file_date',lit(v_file_date))
                

# COMMAND ----------

pitstops_final_df = add_ingestion_date(pitstops_added_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write output in Delta format

# COMMAND ----------

merge_condition='r.driver_id = f.driver_id AND r.race_id = f.race_id AND r.stop = f.stop'
merge_delta_data(pitstops_final_df,'f1_processed','pitstops',processed_folder_path, merge_condition, 'race_id')

# COMMAND ----------

display(spark.read.format('delta').load('/mnt/dlrosies/f1processed/pitstops'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_processed.pitstops

# COMMAND ----------

dbutils.notebook.exit('Success')