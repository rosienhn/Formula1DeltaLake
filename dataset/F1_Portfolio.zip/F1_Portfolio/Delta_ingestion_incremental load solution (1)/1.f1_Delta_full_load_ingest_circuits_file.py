# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC #### Ingest circuits.csv file

# COMMAND ----------

dbutils.widgets.text('p_data_source','')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

v_file_date

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1 - Read the csv file using spark dataframe reader

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType

# COMMAND ----------

circuits_schema = StructType(fields=[StructField('circuitId', IntegerType(), False),
                                     StructField('circuitRef', StringType(), True),
                                     StructField('name', StringType(), True),
                                     StructField('location', StringType(), True),
                                     StructField('country', StringType(), True),
                                     StructField('lat', DoubleType(), True),
                                     StructField('lng', DoubleType(), True),
                                     StructField('alt', IntegerType(), True),
                                     StructField('url', StringType(), True),
])

# COMMAND ----------

circuits_df = spark.read. \
option("header", True). \
schema(circuits_schema).csv(f"{raw_folder_path}/{v_file_date}/circuits.csv")

# COMMAND ----------

circuits_df.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2- Select columns

# COMMAND ----------

circuits_selected_df = circuits_df.select('circuitId','circuitRef','name','location','country','lat','lng','alt')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import lit

# COMMAND ----------

circuits_rename_df = circuits_selected_df.withColumnRenamed('circuitId','circuit_id') \
.withColumnRenamed('circuitRef','circuit_ref') \
.withColumnRenamed('lat','latitude') \
.withColumnRenamed('lng','longitude') \
.withColumnRenamed('alt','altitude') \
.withColumn('data_source', lit(v_data_source)) \
.withColumn('file_date', lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4 - Add ingestion date

# COMMAND ----------

circuits_final_df = add_ingestion_date(circuits_rename_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5 - Write data to datalake as Delta file

# COMMAND ----------

circuits_final_df.write.mode('overwrite').format('delta').saveAsTable('f1_processed.circuits')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/dlrosies/f1processed/circuits

# COMMAND ----------

display(spark.read.format('delta').load('/mnt/dlrosies/f1processed/circuits'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_processed.circuits

# COMMAND ----------

dbutils.notebook.exit('Success')