# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ingest results.csv file

# COMMAND ----------

dbutils.widgets.text('p_data_source','')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

v_file_date

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Read the Json file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, FloatType

# COMMAND ----------

results_schema = StructType(fields=[StructField('resultId', IntegerType(), False),
                                    StructField('raceId', IntegerType(), False),
                                    StructField('driverId', IntegerType(), False),
                                    StructField('constructorId', IntegerType(), False),
                                    StructField('number', IntegerType(), False),
                                    StructField('grid', IntegerType(), False),
                                    StructField('position', IntegerType(), False),
                                    StructField('positionText', StringType(), False),
                                    StructField('positionOrder', IntegerType(), False),
                                    StructField('points', FloatType(), False),
                                    StructField('laps', IntegerType(), False),
                                    StructField('time', StringType(), False),
                                    StructField('milliseconds', IntegerType(), False),
                                    StructField('fastestLap', IntegerType(), False),
                                    StructField('rank', IntegerType(), False),
                                    StructField('fastestLapTime', StringType(), False),
                                    StructField('fastestLapSpeed', StringType(), False),
                                    StructField('statusId', IntegerType(), False),
])

# COMMAND ----------

results_df = spark.read.option('header', True).schema(results_schema).csv(f'{raw_folder_path}/{v_file_date}/results.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import lit, col

# COMMAND ----------

results_renamed_df = results_df.withColumnRenamed('resultId','result_id') \
    .withColumnRenamed('raceId','race_id') \
    .withColumnRenamed('driverId','driver_id') \
    .withColumnRenamed('constructorId','constructor_id') \
    .withColumnRenamed('positionText','position_text') \
    .withColumnRenamed('positionOrder','position_order') \
    .withColumnRenamed('fastestLap','fastest_lap') \
    .withColumnRenamed('fastestLapTime','fastest_lap_time') \
    .withColumnRenamed('fastestLapSpeed','fastest_lap_speed') \
    .withColumn('data_source', lit(v_data_source)) \
    .withColumn('file_date', lit(v_file_date)) 
    


# COMMAND ----------

results_with_ingestion_date_df = add_ingestion_date(results_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Drop unwanted column

# COMMAND ----------

results_final_df = results_with_ingestion_date_df.drop(col('statusId'))

# COMMAND ----------

display(results_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Write output to Delta file

# COMMAND ----------

merge_condition='r.result_id = f.result_id AND r.race_id = f.race_id'
merge_delta_data(results_final_df,'f1_processed','results',processed_folder_path, merge_condition, 'race_id')

# COMMAND ----------

# def merge_delta_data(input_df,db_name,table_name,folder_path, merge_condition, partition_column):
#     spark.conf.set('spark.databricks.optimizer.dynamicPartitionPruning', 'true')

#     from delta.tables import DeltaTable
#     if (spark.catalog.tableExists(f'{db_name}.{table_name}')):
#         deltaTable = DeltaTable.forPath(spark, f'{folder_path}/{table_name}')
#         deltaTable.alias('r').merge(results_final_df.alias('f'), merge_condition) \
#                             .whenMatchedUpdateAll() \
#                             .whenNotMatchedInsertAll() \
#                             .execute()
#     else:
#         input_df.write.mode('overwrite').partitionBy(partition_column).format('delta').saveAsTable(f'{db_name}.{table_name}')

# COMMAND ----------

# spark.conf.set('spark.databricks.optimizer.dynamicPartitionPruning', 'true')

# from delta.tables import DeltaTable
# if (spark.catalog.tableExists('f1_processed.results')):
#     deltaTable = DeltaTable.forPath(spark, '/mnt/dlrosies/processed/results')
#     deltaTable.alias('r').merge(results_final_df.alias('f'), 'r.result_id = f.result_id AND r.race_id = f.race_id') \
#                          .whenMatchedUpdateAll() \
#                          .whenNotMatchedInserteAll() \
#                          .execute()
# else:
#     results_final_df.write.mode('overwrite').partitionBy('race_id').format('delta').saveAsTable('f1_processed.results')

# COMMAND ----------

display(spark.read.format('delta').load('/mnt/dlrosies/f1processed/results'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, count(1)
# MAGIC FROM f1_processed.results
# MAGIC GROUP BY race_id
# MAGIC ORDER BY race_id DESC

# COMMAND ----------

# Check data validity: same drive in the same race has more than 1 record (race 1097 has no data)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, driver_id, count(1)
# MAGIC FROM f1_processed.results
# MAGIC GROUP BY race_id, driver_id
# MAGIC HAVING count(1)>1
# MAGIC order by race_id, driver_id DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_processed.results WHERE race_id = 717 AND driver_id = 373

# COMMAND ----------

dbutils.notebook.exit('Success')