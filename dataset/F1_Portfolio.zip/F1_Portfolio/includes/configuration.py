# Databricks notebook source
raw_folder_path = '/mnt/dlrosies/f1raw'
processed_folder_path = '/mnt/dlrosies/f1processed'
presentation_folder_path = '/mnt/dlrosies/f1presentation'

# COMMAND ----------

## if the folders were not mounted
#raw_folder_path = 'abfss://f1raw@dlrosies.dfs.core.windows.net'
#processed_folder_path = 'abfss://f1processed@dlrosies.dfs.core.windows.net'
#presentation_folder_path = 'abfss://f1presentation@dlrosies.dfs.core.windows.net'