# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ingest drivers.csv file

# COMMAND ----------

dbutils.widgets.text('p_data_source','')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date', '2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Read the Json file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType

# COMMAND ----------

drivers_schema = StructType(fields=[StructField('driverId', IntegerType(), False),
                                   StructField('driverRef', StringType(), False),
                                   StructField('number', IntegerType(), False),
                                   StructField('code', StringType(), False),
                                   StructField('forename', StringType(), False),
                                   StructField('surname', StringType(), False),
                                   StructField('dob', DateType(), False),
                                   StructField('nationality', StringType(), False),
                                   StructField('url', StringType(), False),
                                   StructField('driver_name', StringType(), False)
])

# COMMAND ----------

drivers_df = spark.read.option('header',True).schema(drivers_schema).csv(f'{raw_folder_path}/{v_file_date}/drivers.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import col, concat, lit

# COMMAND ----------

drivers_added_df = drivers_df.withColumnRenamed('driverId','driver_id') \
                             .withColumnRenamed('driverRef','driver_ref') \
                             .withColumn('data_source', lit(v_data_source)) \
                             .withColumn('file_date', lit(v_file_date)) \
                             .withColumn('driver_name', concat(col('forename'), lit(' '), col('surname'))) 

# COMMAND ----------

drivers_with_ingestion_date_df = add_ingestion_date(drivers_added_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Drop unwanted column

# COMMAND ----------

drivers_final_df = drivers_added_df.select('driver_id','driver_ref','driver_name','number','code','dob','nationality','file_date','data_source')

# COMMAND ----------

display(drivers_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Write output to Delta file

# COMMAND ----------

drivers_final_df.write.mode('overwrite').format('delta').saveAsTable('f1_processed.drivers')

# COMMAND ----------

display(spark.read.format('delta').load(f'{processed_folder_path}/drivers'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_processed.drivers

# COMMAND ----------

dbutils.notebook.exit('Success')