# Databricks notebook source
# MAGIC %run ../includes/configuration

# COMMAND ----------

# MAGIC %run ../includes/common_functions

# COMMAND ----------

dbutils.widgets.text('p_data_source','')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Read the csv file using spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, IntegerType, StringType

# COMMAND ----------

laptimes_schema = StructType(fields=[StructField('raceId', IntegerType(), False),
                                      StructField('driverId', IntegerType(), True),
                                      StructField('lap', IntegerType(), True),
                                      StructField('position', IntegerType(), True),
                                      StructField('time', StringType(), True),
                                      StructField('milliseconds', IntegerType(), True)
])

# COMMAND ----------

laptimes_df = spark.read.option('header', True).schema(laptimes_schema).csv(f'{raw_folder_path}/{v_file_date}/lap_times.csv')

# COMMAND ----------

laptimes_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Rename and add columns

# COMMAND ----------

from pyspark.sql.functions import lit

# COMMAND ----------

laptimes_renamed_df = laptimes_df.withColumnRenamed('raceId','race_id') \
                                      .withColumnRenamed('driverId','driver_id') \
                                      .withColumn('data_source',lit(v_data_source)) \
                                      .withColumn('file_date',lit(v_file_date))

# COMMAND ----------

laptimes_final_df = add_ingestion_date(laptimes_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write output in Delta format

# COMMAND ----------

merge_condition='r.driver_id = f.driver_id AND r.lap = f.lap AND r.race_id = f.race_id'
merge_delta_data(laptimes_final_df,'f1_processed','laptimes',processed_folder_path, merge_condition, 'race_id')

# COMMAND ----------

display(spark.read.format('delta').load('/mnt/dlrosies/f1processed/laptimes'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, count(1)
# MAGIC FROM f1_processed.laptimes
# MAGIC GROUP BY race_id

# COMMAND ----------

dbutils.notebook.exit('Success')