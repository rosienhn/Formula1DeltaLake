# Databricks notebook source
df_race_results_sql=spark.read.format('delta').load('/mnt/dlrosies/f1presentation/race_results_sql')
display(df_race_results_sql)

# COMMAND ----------

from pyspark.sql import *
import pandas as pd

# COMMAND ----------

    jdbcHostname = "....database.windows.net"
    jdbcDatabase='db-....'
    jdbcPort="1433"
    properties= {"user":"user","password":"password"}
    url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
    df3=DataFrameWriter(df_race_results_sql)
    df3.jdbc(url,table="[f1_reporting].[race_results_sql]",mode="Overwrite",properties=properties)