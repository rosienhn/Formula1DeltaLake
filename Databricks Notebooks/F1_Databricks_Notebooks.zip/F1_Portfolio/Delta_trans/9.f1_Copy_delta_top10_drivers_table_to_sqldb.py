# Databricks notebook source
df_top10_driver_sql=spark.read.format('delta').load('/mnt/dlrosies/f1presentation/calculated_top10_driver_every_year')
display(df_top10_driver_sql)

# COMMAND ----------

from pyspark.sql import *
import pandas as pd

# COMMAND ----------

    jdbcHostname = "....database.windows.net"
    jdbcDatabase='db-....'
    jdbcPort="1433"
    properties= {"user":"user","password":"password"}
    url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
    df3=DataFrameWriter(df_top10_driver_sql)
    df3.jdbc(url,table="[f1_reporting].[top10_drivers_every_year_sql]",mode="Overwrite",properties=properties)