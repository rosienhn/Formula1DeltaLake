# Databricks notebook source
dbutils.widgets.text('p_file_date','2022-12-24')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# create a new table

# COMMAND ----------

spark.sql(f"""
                CREATE TABLE IF NOT EXISTS f1_presentation.race_results_sql
                (
                    race_year INT,
                    team_name STRING,
                    driver_id INT,
                    driver_name STRING,
                    race_id INT,
                    position INT,
                    points INT,
                    calculated_points INT,
                    created_date TIMESTAMP,
                    updated_date TIMESTAMP
                )
                USING DELTA
""")

# COMMAND ----------

# Create a temp view

# COMMAND ----------

spark.sql(f"""
            CREATE OR REPLACE TEMP VIEW v_race_results
            AS
            SELECT races.race_year, 
                   races.race_id,
                   constructors.constructor_name AS team_name, 
                   drivers.driver_id,
                   drivers.driver_name AS driver_name, 
                    results.position, 
                    results.points, 
                    11-results.position AS calculated_points
            FROM f1_processed.results 
            JOIN f1_processed.drivers  ON (results.driver_id = drivers.driver_id)
            JOIN f1_processed.constructors ON (results.constructor_id = constructors.constructor_id)
            JOIN f1_processed.races  ON (results.race_id = races.race_id)
            WHERE results.position <= 10 AND results.file_date = '{v_file_date}'
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM v_race_results

# COMMAND ----------

# Merge the view with the table

# COMMAND ----------

spark.sql(f"""
                MERGE INTO f1_presentation.race_results_sql AS dr
                USING v_race_results AS vr
                ON dr.race_id = vr.race_id AND dr.driver_id = vr.driver_id
                WHEN MATCHED 
                    THEN UPDATE SET dr.position = vr.position,
                                    dr.points = vr.points,
                                    dr.calculated_points = vr.calculated_points,
                                    dr.updated_date = current_timestamp
                WHEN NOT MATCHED
                    THEN INSERT (race_year,race_id,team_name,driver_id,driver_name,position, points,calculated_points, created_date)
                         VALUES (race_year,race_id,team_name,driver_id,driver_name,position, points,calculated_points, current_timestamp)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(1)
# MAGIC FROM f1_presentation.race_results_sql

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(1)
# MAGIC FROM v_race_results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT* 
# MAGIC FROM f1_presentation.race_results_sql